import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule, provideHttpClient, withFetch } from '@angular/common/http'; // Import necessary modules
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { FileUploadComponent } from './components/file-upload/file-upload.component';
import { FileDataComponent } from './components/file-data/file-data.component';
import { FileUploadService } from './services/file-upload.service';
import { FileDataService } from './services/file-data.service';
import { EmailTemplateComponent } from './components/email-template/email-template.component';
import { AuthenticationComponentComponent } from './components/authentication-component/authentication-component.component';

@NgModule({
  declarations: [
    AppComponent,
    FileUploadComponent,
    FileDataComponent,
    EmailTemplateComponent,
    AuthenticationComponentComponent,
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [
    FileDataService,
    FileUploadService,
    provideHttpClient(withFetch()) // Enable fetch for HttpClient
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
