import { Component } from '@angular/core';
import { AuthService } from '../../services/auth-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-authentication-component',
  templateUrl: './authentication-component.component.html',
  styleUrl: './authentication-component.component.css'
})
export class AuthenticationComponentComponent {
  isLogin: boolean = true;  // Toggle between login and register form
  username: string = '';
  password: string = '';
  email: string = '';
  message: string = '';

  constructor(private authService: AuthService, private router: Router) {}

  // Method for registering a new user
  register(): void {
    const user = { username: this.username, email: this.email, password: this.password };
    this.authService.register(user).subscribe(
      (response) => {
        this.message = 'Registration successful!';
        this.toggleForm(); // Switch to login form after registration
      },
      (error) => {
        this.message = 'Registration failed. Please try again.';
        console.error(error);
      }
    );
  }

  // Method for logging in an existing user
  login(): void {
    const credentials = { username: this.username, password: this.password };
    this.authService.login(credentials).subscribe(
      (response: any) => {
        this.authService.setToken(response.token); // Store JWT token
        this.router.navigate(['/dashboard']);  // Redirect to a dashboard or home page
      },
      (error) => {
        this.message = 'Login failed. Invalid credentials.';
        console.error(error);
      }
    );
  }

  // Toggle between login and register form
  toggleForm(): void {
    this.isLogin = !this.isLogin;
    this.message = '';  // Clear any message on form toggle
  }
}


