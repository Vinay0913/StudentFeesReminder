import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiUrl = 'https://your-api-url';  // Replace with your API URL

  constructor(private http: HttpClient) {}

  // Register a new user
  register(user: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/register`, user);
  }

  // Login an existing user
  login(credentials: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/login`, credentials);
  }

  // Store JWT token in local storage
  setToken(token: string): void {
    localStorage.setItem('authToken', token);
  }

  // Get JWT token from local storage
  getToken(): string | null {
    return localStorage.getItem('authToken');
  }

  // Check if the user is authenticated (has a token)
  isAuthenticated(): boolean {
    return !!this.getToken();
  }

  // Logout the user (remove the token)
  logout(): void {
    localStorage.removeItem('authToken');
  }
}
